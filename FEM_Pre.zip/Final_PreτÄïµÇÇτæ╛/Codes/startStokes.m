function p = startStokes(variate)
% This file is part of FFW.
%
% FFW is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% FFW is distributed inthe hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.


%% Problem Type
% problem = 'Example1';
% problem = 'Stokes_Square_test';
% problem = 'Example1_2domain';
problem = variate.problem;
%% PDE Solver
pdeSolver = 'P2P2P1';

%% Maximum Number Degrees of Freedom
% maxNrDoF = 10000;
maxNrDoF = variate.maxNrDoF;

%% Mark Criterion 
% mark = 'bulk';
% mark = 'maximum';
mark = 'uniform';
% mark = 'graded';

%% Linear System Solver
lsSolver = 'direct';

%% Compute Discrete Solution
p = initFFW(pdeSolver,problem,mark,maxNrDoF,'stokes',lsSolver,'bisection_NVB');  

%%%
p.K = variate.K;
%%%

tic
p = computeSolution(p);
toc
%% Show Discrete Solution
figure(1)
p.params.output.holdIt = false;
p.params.output.lineWidth = 1;
p.params.output.factor = 5000;

set(gcf,'Name','Displacement');
p = show('drawU',p);


% figure(4)
% p = show('drawQ',p);
 
%% Show Grid
figure
p.params.output.holdIt = false; 

set(gcf,'Name','Grid');
p = show('drawGrid',p);

% Show Convergence History
figure
set(gcf,'Name','Convergence History');
p.params.output.drawConvergenceRate = false;
 p.params.integrationDegrees.exactError = 9;
p.params.output.holdIt = true; 
% 
p.params.output.name = [mark,', ',pdeSolver,', ','estimator'];
p = show('drawError_estimatedError',p);
if ~isempty(findstr(problem,'exact'))
    p.params.output.name = [mark,', ',pdeSolver,', ','H^1U'];
     p = show('drawError_H1UsemiError',p);
    p.params.output.name = [mark,', ',pdeSolver,', ','L^2U'];
     p = show('drawError_L2UError',p); 
      p.params.output.name = [mark,', ',pdeSolver,', ','L^2Q'];
     p = show('drawError_L2QError',p); 

    lvl = p.level(end).level;
    rate = zeros(1,lvl-1);
    for ii = 1:lvl
        L2QErr(ii) =  p.level(ii).L2QError;
        L2UErr(ii) = p.level(ii).L2UError;
        H1UsemiErr(ii) = p.level(ii).H1UsemiError;
    end

     rate = L2QErr(2:lvl)./L2QErr(1:lvl-1);
     rate2 = L2UErr(2:lvl)./L2UErr(1:lvl-1);
     rate3 = H1UsemiErr(2:lvl)./H1UsemiErr(1:lvl-1);
     disp(['L2QErr: ',num2str(abs(log(rate)/log(2)))])
    disp(['L2UErr: ', num2str(abs(log(rate2)/log(2)))])
    disp(['H1QErr: ', num2str(abs(log(rate3)/log(2)))])

end