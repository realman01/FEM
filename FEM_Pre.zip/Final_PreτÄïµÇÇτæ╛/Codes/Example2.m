function p = Example2(p)
% This file is part of FFW.
% f=0
% g=0
%u \neq 0 on partial omega
% u(x,0)=[0 ; x*(2-x)]  u(x,2) = [0 8*x*(1-x)]

%% Problem definition %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PDE definition
p.problem.geom = 'Example2'; 
p.problem.f = @f;
p.problem.u_D = @u_D;
p.problem.gradU_D = @gradU_D;
p.problem.g = @g;
p.problem.kappa = @kappa;
% p.problem.Dkappa = @Dkappa;
p.problem.lambda = @lambda;
p.problem.mu = @mu;


return

%% Dirichlet boundary values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = u_D(pts,p)
 x = pts(:,1);
 y = pts(:,2);
 nrPts = size(pts,1);
 z = zeros(nrPts,2);
 r = y;
 K = 1e-2; phi_p = 0.4; mu=1;
 
 id11 = find(x>=0 & x<=0.5 & y >1.5 & y <=2);
% % r(id11) = y(id11) - 1.5;
% % id12 = find(x>=0 & x<=0.5 & y >1 & y <=1.5);
% % r(id12) = - min(abs(y(id12) - 1.5),abs(x(id12)-0.5));
% % id13 = find(x>=0 & x<=0.5 & y >= 0 & y <=1);
% % r(id13) = - sqrt((x(id13)-0.5).^2 + (y(id13)-1).^2);
% % 
% % id21 = find(x>0.5 & x<=1 & y >1.5 & y <=2);
% % r(id21) =  sqrt((x(id21)-0.5).^2 + (y(id21)-1.5).^2);
% % id22 = find(x>0.5 & x<=1 & y >1 & y <= 1.5);
% % r(id22) =  min(abs(y(id22) - 1),abs(x(id22)-0.5));
% % id23  = find(x>0.5 & x<=1 & y >0.5 & y <= 1);
% % r(id23) =  - min(abs(y(id23) - 1),abs(x(id23)-1.5));
% % id24  = find(x>0.5 & x<=1 & y >=0 & y <= 0.5);
% % r(id24) = - sqrt((x(id24)-1).^2 + (y(id24)-0.5).^2);
% % 
% % id31 = find(x>1 & x<=1.5 & y >1 & y <=2);
% % r(id31) =  sqrt((x(id31)-1).^2 + (y(id31)-1).^2);
% % id32 = find(x>1 & x<=1.5 & y >0.5 & y <=1);
% % r(id32) =   min(abs(y(id32) - 0.5),abs(x(id32)-1));
% % id33 = find(x>1 & x<=1.5 & y >=0 & y <=0.5);
% % r(id33) =  - min(abs(y(id33) - 0.5),abs(x(id33)-1.5));
% % 
% % id41 = find(x>1.5 & x<=2 & y >0.5 & y <=2);
% % r(id41) =  sqrt((x(id41)-1.5).^2 + (y(id41)-0.5).^2);
% % id42 = find(x>1.5 & x<=2 & y >=0 & y <=0.5);
% % r(id42) =  min(abs(y(id42) - 0),abs(x(id42)-1.5));
 
 
 gd = (r./2).* (r-2);
 z(:,1) = gd;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%  id = find(r>0);
%  gd1 = -1/2 * (r(id,1).^2-1) + (1/2 - K).* (r(id,1)-1) ./ (sqrt(phi_p * K) + 1);
%  z(id,:) = [gd1,zeros(length(id),1)];
%  
%  id = find(r<=0);
%  Y(id,1) = zeros(length(id),1);
%  gd2 = -1/2 * (Y(id,1).^2-1) + (1/2 - K).* (Y(id,1)-1) ./ (sqrt(phi_p * K) + 1);
%  gd2 = gd2 .* exp(y(id,1) .* sqrt(phi_p / K)) - (K/mu) .* tanh(r(id,1) .* sqrt(phi_p / K));
%  z(id,:) = [gd2,zeros(length(id),1)];

% function z = gradU_D(pts,p)
% x = pts(:,1);
% y = pts(:,2);
% nrPts = size(pts,1);
%  %[du1dx, du1dy]
% %[du2dx, du2dy]
%  z = zeros(nrPts,2,2);
%  
%  id = find(y==0);
%  z(id,1,:) = zeros(length(id),2);
%  z(id,2,:) = [2-2*x(id), zeros(length(id),1)];
% 
%  id = find(y==2);
%  z(id,1,:) = zeros(length(id),2);
%  z(id,2,:) = [8-16*x(id), zeros(length(id),1)];

%% Neumann boundary values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = g(pts,normals,p)
nrPts = size(pts,1);
z = zeros(nrPts,2);

%% Wrapper for function handles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = f(pts,p)
nrPts = size(pts,1);
z = zeros(nrPts,2);


%% elliptic PDE coefficent kappa ( div(kappa*grad_u) ) %%%%%%%%%%%%%%%%%%%%
function z = kappa(pts,p)
nrPts = size(pts,1);
dim = size(pts,2);
x = pts(:,1);
z = zeros(dim,dim,nrPts);

K = 1e-2; theta = 100; mu = 1; mu_eff = 2.5;
epsilon = sqrt(K);
y = pts(:,2); 

r = zeros(nrPts,1);

id11 = find(x>=0 & x<=0.5 & y >1.5 & y <=2);
r(id11) = y(id11) - 1.5;
id12 = find(x>=0 & x<=0.5 & y >1 & y <=1.5);
r(id12) = - min(abs(y(id12) - 1.5),abs(x(id12)-0.5));
id13 = find(x>=0 & x<=0.5 & y >= 0 & y <=1);
r(id13) = - sqrt((x(id13)-0.5).^2 + (y(id13)-1).^2);

id21 = find(x>0.5 & x<=1 & y >1.5 & y <=2);
r(id21) =  sqrt((x(id21)-0.5).^2 + (y(id21)-1.5).^2);
id22 = find(x>0.5 & x<=1 & y >1 & y <= 1.5);
r(id22) =  min(abs(y(id22) - 1),abs(x(id22)-0.5));
id23  = find(x>0.5 & x<=1 & y >0.5 & y <= 1);
r(id23) =  - min(abs(y(id23) - 1),abs(x(id23)-1.5));
id24  = find(x>0.5 & x<=1 & y >=0 & y <= 0.5);
r(id24) = - sqrt((x(id24)-1).^2 + (y(id24)-0.5).^2);

id31 = find(x>1 & x<=1.5 & y >1 & y <=2);
r(id31) =  sqrt((x(id31)-1).^2 + (y(id31)-1).^2);
id32 = find(x>1 & x<=1.5 & y >0.5 & y <=1);
r(id32) =   min(abs(y(id32) - 0.5),abs(x(id32)-1));
id33 = find(x>1 & x<=1.5 & y >=0 & y <=0.5);
r(id33) =  - min(abs(y(id33) - 0.5),abs(x(id33)-1.5));

id41 = find(x>1.5 & x<=2 & y >0.5 & y <=2);
r(id41) =  sqrt((x(id41)-1.5).^2 + (y(id41)-0.5).^2);
id42 = find(x>1.5 & x<=2 & y >=0 & y <=0.5);
r(id42) =  min(abs(y(id42) - 0),abs(x(id42)-1.5));


phi_1 = (1/2) * (1- mu_eff / mu) * tanh((theta .* r)./ epsilon)  + (1/2) * (1 + mu_eff / mu);
%   z = reshape(repmat(eye(dim),1,nrPts),dim,dim,nrPts);
for i =1 : nrPts
    z(:,:,i) = mu .* phi_1(i,1) * eye(dim,dim);
end

 
%% elliptic PDE coefficent mu ( mu*u ) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = mu(pts,p)
x = pts(:,1);
nrPts = size(pts,1);
% dim = size(pts,2);
 z = zeros(nrPts,1);

K = 1e-2; theta = 100; mu = 1;
epsilon = sqrt(K);
y = pts(:,2);

r = zeros(nrPts,1);

id11 = find(x>=0 & x<=0.5 & y >1.5 & y <=2);
r(id11) = y(id11) - 1.5;
id12 = find(x>=0 & x<=0.5 & y >1 & y <=1.5);
r(id12) = - min(abs(y(id12) - 1.5),abs(x(id12)-0.5));
id13 = find(x>=0 & x<=0.5 & y >= 0 & y <=1);
r(id13) = - sqrt((x(id13)-0.5).^2 + (y(id13)-1).^2);

id21 = find(x>0.5 & x<=1 & y >1.5 & y <=2);
r(id21) =  sqrt((x(id21)-0.5).^2 + (y(id21)-1.5).^2);
id22 = find(x>0.5 & x<=1 & y >1 & y <= 1.5);
r(id22) =  min(abs(y(id22) - 1),abs(x(id22)-0.5));
id23  = find(x>0.5 & x<=1 & y >0.5 & y <= 1);
r(id23) =  - min(abs(y(id23) - 1),abs(x(id23)-1.5));
id24  = find(x>0.5 & x<=1 & y >=0 & y <= 0.5);
r(id24) = - sqrt((x(id24)-1).^2 + (y(id24)-0.5).^2);

id31 = find(x>1 & x<=1.5 & y >1 & y <=2);
r(id31) =  sqrt((x(id31)-1).^2 + (y(id31)-1).^2);
id32 = find(x>1 & x<=1.5 & y >0.5 & y <=1);
r(id32) =   min(abs(y(id32) - 0.5),abs(x(id32)-1));
id33 = find(x>1 & x<=1.5 & y >=0 & y <=0.5);
r(id33) =  - min(abs(y(id33) - 0.5),abs(x(id33)-1.5));

id41 = find(x>1.5 & x<=2 & y >0.5 & y <=2);
r(id41) =  sqrt((x(id41)-1.5).^2 + (y(id41)-0.5).^2);
id42 = find(x>1.5 & x<=2 & y >=0 & y <=0.5);
r(id42) =  min(abs(y(id42) - 0),abs(x(id42)-1.5));

% id1 = find(x>=0 & x<=0.5);
% y(id1) = y(id1) - 1.5;
% id2 = find(x>0.5 & x<=1);
% y(id2) = y(id2) - 1;
% id3 = find(x>1 & x<=1.5);
% y(id3) = y(id3) - 0.5;



phi_2 = -1/2 * tanh((theta .* r)./epsilon) + 1/2;


z(:,1) = mu .* phi_2(:,1) .* (1/K) ;


