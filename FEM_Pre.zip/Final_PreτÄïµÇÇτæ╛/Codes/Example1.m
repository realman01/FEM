function p = Example1(p)
% This file is part of FFW.
% f=0
% g=0
%u \neq 0 on partial omega
% u(x,0)=[0 ; x*(2-x)]  u(x,2) = [0 8*x*(1-x)]

%% Problem definition %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PDE definition
p.problem.geom = 'Example1'; 
p.problem.f = @f;
p.problem.u_D = @u_D;
p.problem.gradU_D = @gradU_D;
p.problem.g = @g;
p.problem.kappa = @kappa;
% p.problem.Dkappa = @Dkappa;
p.problem.lambda = @lambda;
p.problem.mu = @mu;


return

%% Dirichlet boundary values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = u_D(pts,p)
 x = pts(:,1);
 y = pts(:,2);
 nrPts = size(pts,1);
 z = zeros(nrPts,2);
 
 K = p.K; phi_p = 0.4; mu=1;
 
 
 id = find(y>0);
 gd1 = -1/2 * (y(id,1).^2-1) + (1/2 - K).* (y(id,1)-1) ./ (sqrt(phi_p * K) + 1);
 z(id,:) = [gd1,zeros(length(id),1)];
 
 id = find(y<=0);
 Y(id,1) = zeros(length(id),1);
 gd2 = -1/2 * (zeros(size(id,1),1).^2-1) + (1/2 - K).* (zeros(size(id,1),1)-1) ./ (sqrt(phi_p * K) + 1);
 gd2 = gd2 .* exp(y(id,1) .* sqrt(phi_p / K)) - (K/mu) .* tanh(y(id,1) .* sqrt(phi_p / K));
 z(id,:) = [gd2,zeros(length(id),1)];

% function z = gradU_D(pts,p)
% x = pts(:,1);
% y = pts(:,2);
% nrPts = size(pts,1);
%  %[du1dx, du1dy]
% %[du2dx, du2dy]
%  z = zeros(nrPts,2,2);
%  
%  id = find(y==0);
%  z(id,1,:) = zeros(length(id),2);
%  z(id,2,:) = [2-2*x(id), zeros(length(id),1)];
% 
%  id = find(y==2);
%  z(id,1,:) = zeros(length(id),2);
%  z(id,2,:) = [8-16*x(id), zeros(length(id),1)];

%% Neumann boundary values %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = g(pts,normals,p)
nrPts = size(pts,1);
z = zeros(nrPts,2);

%% Wrapper for function handles %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = f(pts,p)
nrPts = size(pts,1);
z = ones(nrPts,2);


%% elliptic PDE coefficent kappa ( div(kappa*grad_u) ) %%%%%%%%%%%%%%%%%%%%
function z = kappa(pts,p)
nrPts = size(pts,1);
dim = size(pts,2);
z = zeros(dim,dim,nrPts);

K = p.K; theta = 100; mu = 1; mu_eff = 2.5;
epsilon = sqrt(K);
y = pts(:,2);
phi_1 = (1/2) * (1- mu_eff / mu) * tanh((theta .* y)./ epsilon)  + (1/2) * (1 + mu_eff / mu);
%   z = reshape(repmat(eye(dim),1,nrPts),dim,dim,nrPts);
for i =1 : nrPts
    z(:,:,i) = mu .* phi_1(i,1) * eye(dim,dim);
end

 
%% elliptic PDE coefficent mu ( mu*u ) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function z = mu(pts,p)
nrPts = size(pts,1);
% dim = size(pts,2);
 z = zeros(nrPts,1);

K = p.K; theta = 100; mu = 1;
epsilon = sqrt(K);
y = pts(:,2);
phi_2 = -1/2 * tanh((theta .* y)./epsilon) + 1/2;


z(:,1) = mu .* phi_2(:,1) .* (1/K) ;


